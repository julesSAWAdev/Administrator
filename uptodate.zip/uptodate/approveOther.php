<?php
include('connection.php');
 $shopid = $_GET['shopid']; 
 
 $origin =$_GET['origin'];

 if ($origin == "web") {
 			$sql = "SELECT * FROM tbl_other_shops WHERE shop_id='$shopid'";
 			$res = $result = mysqli_query($conn, $sql);
 			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

 			$base = "GofixShopO";
 			$shop_id = $row['shop_id'];
 			$user_id = $row['user_id'];
 			$origin = $row['origin'];
 			$username = $base.$shopid.$user_id.$origin;


 			$insert = "INSERT INTO tbl_admin_login(username,password,roles,user_id,status,shopid,origin) VALUES('$username','GofixShop','other','$user_id','1','$shop_id','$origin')";
 			$insres = mysqli_query($conn, $insert);

 			if($insres){

            $query = "UPDATE tbl_other_shops SET status = '1' WHERE shop_id='$shopid'";
            $result = mysqli_query($conn, $query);

            if ($result) {
            	 echo "<script>window.location = 'othershops.php'</script>";
            }
        }
    }else{
    	$sql = "SELECT * FROM tbl_other_shops WHERE shop_id='$shopid'";
 			$res = $result = mysqli_query($conn, $sql);
 			$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

 			$base = "GofixShopO";
 			$shop_id = $row['shop_id'];
 			$user_id = $row['user_id'];
 			$origin = $row['origin'];
 			$username = $base.$shopid.$user_id.$origin;


 			$insert = "INSERT INTO tbl_admin_login(username,password,roles,user_id,status,shopid,origin) VALUES('$username','GofixShop','other','$user_id','1','$shop_id','$origin')";
 			$insres = mysqli_query($conn, $insert);

 			if($insres){

            $query = "UPDATE tbl_other_shops SET status = '1' WHERE shop_id='$shopid'";
            $result = mysqli_query($conn, $query);

            if ($result) {
            	 echo "<script>window.location = 'othershops.php'</script>";
            }
        }
    }
?>